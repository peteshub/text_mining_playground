#!/bin/bash

find . -name "*.pdf" -exec java -jar pdfbox-app-2.0.7.jar ExtractText -html {} {}.txt \;

